# CS170-FeatureSelection
Feature Selection with Nearest Neighbor
- The Nearest Neighbor classifier is used inside the following “wrappers”, which does various kinds of searches: 
  - Foward Selection
  - Backward Selection
