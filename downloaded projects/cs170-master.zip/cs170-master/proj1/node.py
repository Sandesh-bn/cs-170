"""
    node.py
    Author: Joel Gomez
    Date created: 2016/11/04
    Python Version 3.5.2
"""
import puzzle

class node:
    def __init__(self, state, parent=None):
        self.STATE = state
        self.MISPLACED = None
        self.MANHATTAN = None
        if parent is None:
            self.PATH_COST = 0
            self.PARENT = None
        else:
            self.PARENT = parent
            self.PATH_COST = self.PARENT.PATH_COST + 1

    def __getitem__(self, item):
        return self.STATE[item]

    def __index__(self, item):
        return self.STATE.index(item)

    def __lt__(self, other):
        return self.STATE < other.STATE

    def manhattan(self):
        if self.MANHATTAN is None:
            self.MANHATTAN = puzzle.find_manhattan(self.STATE)
        return self.MANHATTAN

    def misplaced(self):
        if self.MISPLACED is None:
            self.MISPLACED = puzzle.find_misplaced(self.STATE)
        return self.MISPLACED

    def swap(self, x, y):
        self.STATE[x], self.STATE[y] = self.STATE[y], self.STATE[x]
        return

