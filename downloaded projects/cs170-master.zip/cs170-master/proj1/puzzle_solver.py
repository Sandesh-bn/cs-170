#!/usr/bin/env python3
"""
    puzzle_solver.py
    Author: Joel Gomez
    Date created: 2016/11/02
    Python Version 3.5.2
"""

import sys
import search
import puzzle
import node

# Several test puzzles
# defaultPuzzle = [['1', '2', '3'], ['4', '0', '5'], ['6', '7', '8']]
# defaultPuzzle = [['1', '2', '3'], ['4', '0', '6'], ['7', '5', '8']]
# defaultPuzzle = [['4', '1', '2'], ['7', '5', '3'], ['8', '6', '0']]
# defaultPuzzle = [['4', '2', '8'], ['6', '0', '3'], ['7', '5', '1']]
defaultPuzzle = [['0', '8', '7'], ['6', '5', '4'], ['3', '2', '1']]
# defaultPuzzle = [['8', '6', '7'], ['2', '5', '4'], ['3', '0', '1']]
# defaultPuzzle = [['1', '2', '3', '4'], ['5', '6', '7', '8'], 
    # ['9', '10', '11', '12'], ['13', '15', '14', '0']]
# defaultPuzzle = [['1', '2', '3', '4'], ['5', '6', '7', '8'], 
    # ['9', '10', '11', '12'], ['13', '14', '15', '0']]

def print_intro():
    """
    Prints the pretty intro text for CLI.
    """
    print('\n' + '"Eight Puzzle" Solver v1.0 by Joel Gomez'.center(70, '*') + '\n')
    return

def get_puzzle():
    """
    Gets the user selection for default or manual puzzle.
    """
    selectedPuzzle = []
    while 1:
        userSelection = input('Type "1" to use the default puzzle, or "2"' + \
                ' to enter your own: ')
        if userSelection == '1' or userSelection == '2':
            break
        else:
            print('Sorry, that is not a valid option..')
    if userSelection == '1':
        selectedPuzzle = defaultPuzzle
    elif userSelection == '2':
        selectedPuzzle = manual_puzzle()
    return selectedPuzzle

def get_algorithm():
    """
    Gets the user selection for the desired algorithm
    """
    print('Enter your choice of algorithm:')
    print('\t1. Uniform Cost Search')
    print('\t2. A* with the Misplaced Tile heuristic')
    print('\t3. A* with the Manhattan distance heuristic')
    while 1:
        choice = input()
        if not choice.isdigit() or choice < '1' or choice > '3':
            print('Please select a valid option.')
        else:
            break
    return int(choice)

def validate_row(rowNum):
    """
    Gets and validates a row of numbers from the user.
    Takes a single parameter, the string value of the row to be requested.
    """
    error = 0
    while 1:
        row = input('Enter row ' + rowNum + ', use space or tabs between numbers: ')
        puzzleSize = len(row.split())
        for num in row.split():
            if not num.isdigit():
                print('Please enter ONLY  numbers separated by whitespace.')
                error = 1
                break
            else:
                error = 0
        if error:
            continue
        else:
            break
    return row

def manual_puzzle():
    """
    Gets user entry for a manual puzzle, returns the puzzle in a structured form.
    """
    puzzle = []
    print('Enter your puzzle, a row of numbers at a time. Use a "0" to ' + \
            'represent the blank position.')
    puzzle.append(validate_row('1').split())
    for i in range(2,len(puzzle[0])+1):
        puzzle.append(validate_row(str(i)).split())

    return puzzle

def main():
    print_intro()
    userPuzzle = puzzle.flatten(get_puzzle())
    puzzle1 = puzzle.puzzle(userPuzzle)
    alg = get_algorithm()
    print('Puzzle to be solved:')
    puzzle.draw_puzzle(userPuzzle)
    if not puzzle1.SOLVABLE:
        print('Warning, this puzzle cannot be solved!')
        while 1:
            print('Select an option to continue:')
            print('1. OK, quit.')
            print('2. Who cares, onward ho!')
            selection = input()
            if not (selection > '0' and selection < '3'):
                print('That\'s not a valid option. Please try again.')
                continue
            elif selection == '1':
                print('OK, Bye!!!')
                sys.exit(0)
            else:
                break
    result, expanded, max = search.search(puzzle1,alg)
    print('\n' + 'Goal!!'.center(70, '*') + '\n')
    print('To solve this problem the search algorithm expanded a total of ' + \
            str(expanded) + ' nodes.')
    print('The maximum number of nodes in the queue at any one time was ' + str(max))
    print('The depth of the goal node was ' + str(result.PATH_COST) + '\n')
    return

if __name__ == '__main__':
    main()
