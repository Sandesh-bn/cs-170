"""
    puzzle.py
    Author: Joel Gomez
    Date created: 2016/11/04
    Python Version 3.5.2
"""
import node
import math

def move_left(state, pos):
    """
    Definition for left movement on the puzzle board
    """
    size = len(expand_puzzle(state.STATE))
    if pos in range(0, size*(size-1)+1, size):
        return 0
    else:
        child = node.node(list(state), state)
        child.swap(pos, pos-1)
        return child

def move_right(state, pos):
    """
    Definition for right movement on the puzzle board
    """
    size = len(expand_puzzle(state.STATE))
    if pos in range(size-1, size*size, size):
        return 0
    else:
        child = node.node(list(state), state)
        child.swap(pos, pos+1)
        return child

def move_up(state, pos):
    """
    Definition for upward movement on the puzzle board
    """
    size = len(expand_puzzle(state.STATE))
    if pos in range(0, size):
        return 0
    else:
        child = node.node(list(state), state)
        child.swap(pos, pos-size)
        return child

def move_down(state, pos):
    """
    Definition for downward movement on the puzzle board
    """
    size = len(expand_puzzle(state.STATE))
    if pos in range(size*(size-1), size*size):
        return 0
    else:
        child = node.node(list(state), state)
        child.swap(pos, pos+size)
        return child

def find_manhattan(puzzle):
    """
    Finds the Manhattan distance for a given puzzle state
    """
    eState = expand_puzzle(puzzle)
    eGoal = get_goal_state(eState)
    goal = flatten(eGoal)
    distance = 0
    size = len(eState)
    dSize = size*2
    sqSize = size*size

    for i in range(1, sqSize):
        statePos = puzzle.index(str(i))
        goalPos = goal.index(str(i))
        if statePos == goalPos:
            continue

        elif statePos in range(0, size):
            if goalPos in range(0, size):
                distance += abs(statePos - goalPos)
            elif goalPos in range(size, dSize):
                statePos += size
                distance += abs(statePos - goalPos) + 1
            else:
                statePos += dSize
                distance += abs(statePos - goalPos) + 2
        elif statePos in range(size, dSize):
            if goalPos in range(size, dSize):
                distance += abs(statePos - goalPos)
            elif goalPos in range(0, size):
                statePos -= size
                distance += abs(statePos - goalPos) + 1
            else:
                statePos += size
                distance += abs(statePos - goalPos) + 1
        elif statePos in range(dSize, sqSize):
            if goalPos in range(dSize, sqSize):
                distance += abs(statePos - goalPos)
            elif goalPos in range(size, dSize):
                statePos -= size
                distance += abs(statePos - goalPos) + 1
            else:
                statePos -= dSize
                distance += abs(statePos - goalPos) + 2
    return distance

def find_misplaced(puzzle):
    """
    Finds the misplaced tile count for a given puzzle state
    """
    flatState = flatten(puzzle)
    flatGoal = get_goal_state(expand_puzzle(puzzle))
    size = len(flatState)
    count = 0
    for i in range(0, size):
        if puzzle[i] is 0:
            continue
        if flatState[i] != flatGoal[i]:
            count += 1
    return count

def check_solvability(puzzle):
    """
    Checks solvability of puzzle based on number of inversions. Inspired from
    https://www.cs.bham.ac.uk/~mdr/teaching/modules04/java2/TilesSolvability.html
    """
    puzzleLen = len(puzzle)
    blankRow = find_blank(puzzle)
    inversions = count_inversions(flatten(puzzle))

    gridWidthEven = puzzleLen % 2 == 0
    gridWidthOdd = puzzleLen % 2 == 1
    inversionsEven = inversions % 2 == 0
    blankEven = (puzzleLen - blankRow + 1) % 2 == 0
    blankOdd = (puzzleLen - blankRow + 1) % 2 == 1

    if (gridWidthOdd and inversionsEven) or \
            (gridWidthEven and blankOdd) and not inversionsEven or \
            (gridWidthEven and blankEven) and inversionsEven:
        return True
    else:
        return False

def flatten(puzzle):
    """
    Flattens a puzzle in a n-dimensional list to a 1-dimensional list
    """
    flatPuzzle = []
    for row in puzzle:
        flatPuzzle += row
    return flatPuzzle

def expand_puzzle(flatPuzzle):
    """
    Expands a puzzle from a 1-dimensional list to an n-dimensional list
    """
    size = int(math.sqrt(len(flatPuzzle)))
    expanded = []
    j = 0
    k = size
    for i in range(size):
        expanded.append(flatPuzzle[j:k])
        j += size
        k += size

    return expanded

def find_blank(puzzle):
    """
    Finds the row containing the blank tile
    """
    blankRow = 0
    for i,row in enumerate(puzzle):
        if '0' in row:
            blankRow = i+1
            break
    return blankRow

def merge_and_count(listA, listB):
    """
    Merges two list together while keeping track of total inversions.
    Takes in two lists, each containing a list of numbers, and running total 
    of inversions found since last merge.
    """
    i = 0
    j = 0
    count = listA[1] + listB[1]
    result = []
    for num in range(len(listA[0]+listB[0])+1):
        if i < len(listA[0]) and j < len(listB[0]):
            if listA[0][i] < listB[0][j]:
                result.append(listA[0][i])
                i += 1
            else:
                result.append(listB[0][j])
                j += 1
                count += len(listA[0]) - i
        elif i < len(listA[0]):
            result.append(listA[0][i])
            i += 1
        elif j < len(listB[0]):
            result.append(listB[0][j])
            j += 1

    return [result, count]

def count_and_sort(numList):
    """
    Recursively finds inversions using divide and conquer
    """
    if len(numList) == 1:
        return [numList,0]
    else:
        mid = int(len(numList)/2)
        left = count_and_sort(numList[:mid])
        right = count_and_sort(numList[mid:])
        center = merge_and_count(left, right)
        return center

def count_inversions(puzzle):
    return count_and_sort(puzzle)[1]

def draw_puzzle(puzzle):
    """
    Draws a picture of the puzzle (works best with single digits)
    """
    puzzle = expand_puzzle(puzzle)
    print(''.center(len((puzzle[0])*4)+1,'-'))
    for row in puzzle:
        print('| ' + ' | '.join(map(str,row)) + ' |')
        print(''.center(len((puzzle[0])*4)+1,'-'))
    return

def get_goal_state(puzzle):
    """
    Finds the goal state of a given puzzle by sorting the tiles
    """
    goalState = []
    size = len(puzzle)
    goalState = flatten(puzzle)
    goalState.sort()
    goalState.remove('0')
    goalState.append('0')
    return goalState

def check_goal(state, goalState):
    """
    Checks to see if current state and goal state match
    """
    if state == goalState:
        return 1
    else:
        return 0

class puzzle:
    def __init__(self, init):
        self.INITIAL_STATE = node.node(init)
        self.ACTIONS = [move_left, move_right, move_up, move_down]
        self.GOAL_STATE = get_goal_state(init) 
        self.GOAL_TEST = check_goal
        self.SOLVABLE = check_solvability(init)
        self.find_misplaced = find_misplaced
        self.find_manhattan = find_manhattan

