"""
    search.py
    Author: Joel Gomez
    Date created: 2016/11/04
    Python Version 3.5.2
"""
import heapq
import puzzle

def print_expand_msg(state):
    """
    Prints a message to the screen with the current puzzle state
    """
    puzzle.draw_puzzle(state)
    print('Expanding this node...\n')
    return

def expand_node(node, actions):
    """
    Retrieves the children of a given node
    """
    children = []
    blank = node.STATE.index('0')

    for action in actions:
        child = action(node, blank)
        if child:
            children.append(child)
    return children

def get_diameter(puzzle):
    """
    Attempts to find the diameter of a given puzzle
    """
    size = len(puzzle)
    if size == 9:
        return 31
    elif size == 15:
        return 80
    elif size == 25:
        return 208
    else:
        return float('inf')

def search(puzzle, alg):
    """
    Main search function for searching based on a chosen algorithm
    1 - UCS
    2 - A* Misplaced Tile
    3 - A* Manhattan Distance
    """
    puzzleDiameter = get_diameter(puzzle.INITIAL_STATE.STATE)
    totalExpanded = 0
    queueLen = 0

    if puzzle.GOAL_TEST(puzzle.INITIAL_STATE.STATE, puzzle.GOAL_STATE):
        print('\nThis puzzle is already at the goal state!')
        return puzzle.INITIAL_STATE, totalExpanded, queueLen
    nodes = []
    deadEnds = {}

    heapq.heappush(nodes,[float('inf'),puzzle.INITIAL_STATE])

    while 1:
        if not nodes:
            return 0,0,0

        queueLen = max(queueLen, len(nodes))

        cost, node = heapq.heappop(nodes)
        deadEnds[tuple(node.STATE)] = True

        print('The best state to expand with a',end=' ')
        if alg == 1:
            print('g(n) = ' + str(node.PATH_COST) + ' and h(n) = ' + '0' + ' is...')
        elif alg == 2:
            print('g(n) = '+ str(node.PATH_COST) + ' and h(n) = ' + \
                    str(node.misplaced())
                    + ' is...')
        else:
            print('g(n) = '+ str(node.PATH_COST) + ' and h(n) = ' + \
                    str(node.manhattan())
                    + ' is...')
        print_expand_msg(node.STATE)

        for child in expand_node(node, puzzle.ACTIONS):
            if tuple(child.STATE) not in deadEnds:
                if child.PATH_COST <= puzzleDiameter:
                    if alg is 1:
                        heapq.heappush(nodes, [child.PATH_COST, child])
                    elif alg is 2:
                        heapq.heappush(nodes, \
                                [child.misplaced() + \
                                            child.PATH_COST, child])
                    else:
                        heapq.heappush(nodes, \
                                [child.manhattan() + \
                                            child.PATH_COST, child])
                    totalExpanded += 1

            if puzzle.GOAL_TEST(child.STATE, puzzle.GOAL_STATE):
                return child, totalExpanded, queueLen
