# Nearest Neighbor Classifier 
A Nearest Neighbor Classifier created in Matlab
A project for Aritificial Intellegence class in UCR

The classifier uses three different search algorithms:

1. Forward Selection
2. Backward Elimination 
3. An algorithm I created

For the algorithm I created, I eliminate the number of instances the program will test with nearest neighbor classifier. This would greatly increase the speed of the classifying speed but also keep a certain amount of accuracy. 

