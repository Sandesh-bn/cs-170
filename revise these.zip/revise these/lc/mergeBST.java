merge two bst

convert each bst to linkedlist.
merge the linkedlist
convert merged linkedlist to bst