

Maximal Rectangle   Add to List QuestionEditorial Solution  My Submissions
Total Accepted: 55494
Total Submissions: 214806
Difficulty: Hard
Contributors: Admin
Given a 2D binary matrix filled with 0's and 1's, find the largest rectangle containing only 1's and return its area.

For example, given the following matrix:

1 0 1 0 0
1 0 1 1 1
1 1 1 1 1
1 0 0 1 0

review this

