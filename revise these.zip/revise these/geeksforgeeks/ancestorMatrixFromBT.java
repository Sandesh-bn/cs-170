  static void populateAncestorMatrix(Node root, int[][] mat, int n) {
		if (root == null) {
			return;
		}
		populateAncestorMatrix(root.left, mat, n);
		populateAncestorMatrix(root.right, mat, n);
		
		if (root.left != null) {
			// set 1 for current child
			mat[root.item][root.left.item] = 1;
			// all children of current child are also children of root
			for (int j = 0; j < n; j++) {
				if (mat[root.left.item][j] == 1) {
					mat[root.item][j] = 1;
				}
			}
		}
		if (root.right != null) {
			mat[root.item][root.right.item] = 1;
			for (int j = 0; j < n; j++) {
				if (mat[root.right.item][j] == 1) {
					mat[root.item][j] = 1;
				}
			}
		}
	}