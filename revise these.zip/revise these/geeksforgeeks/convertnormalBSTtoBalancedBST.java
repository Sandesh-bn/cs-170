


// traverse the tree and add it to array/list
// create  bst from the list.