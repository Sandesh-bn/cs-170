http://massivealgorithms.blogspot.com/2015/06/how-to-check-if-instance-of-8-puzzle-is.html

http://www.geeksforgeeks.org/check-instance-8-puzzle-solvable/

