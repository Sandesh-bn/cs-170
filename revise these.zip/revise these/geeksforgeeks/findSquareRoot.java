http://www.geeksforgeeks.org/square-root-of-a-perfect-square/
https://www.youtube.com/watch?v=jTWxFGmWoZg