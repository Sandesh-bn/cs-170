https://www.careercup.com/question?id=5692379756494848

Given two pre-order traversal arrays of two binary search tree respectively, find first pair of non-matching leaves. 
Follow Up: If they are general binary trees instead of BSTs, could you solve it? give out your reason. 

http://shirleyisnotageek.blogspot.com/2016/11/first-pair-non-matching-leaves.html