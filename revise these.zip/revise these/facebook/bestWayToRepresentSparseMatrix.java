What data structure would you use to store the entries of a sparse matrix?

if matrix contains only 0s and 1s use adjacency list.

use hashmap
key = row-order number/col-order number
value = data in that cell