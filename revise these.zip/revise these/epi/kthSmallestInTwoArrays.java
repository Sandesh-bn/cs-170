http://stackoverflow.com/questions/4607945/how-to-find-the-kth-smallest-element-in-the-union-of-two-sorted-arrays

 Youare given two sorted arrays A and B of lengths m and n,respec-
tively,and a positive integer k E [I,m + n). Design an algorithm that runs in O(logk)
time for computing the k-th smallest element in array formed by merging A and B.
Array elements may be duplicated within and between A and B.
