/*
: For a certain application, processes need to locknodes in abinary tree.
Implement a library forlocking nodes in a binary tree,subjectto the constraint that a
node cannot be lockedif any of its descendants or ancestors are locked. Specifically,
write functions isLockO, lockO, and unlock 0,with time complexities0(1), O(h),
and O(h). Here h is the height of the binary tree. Assume that each node has a parent
~.
*/
http://www.geeksforgeeks.org/locking-and-unlocking-of-resources-in-the-form-of-n-ary-tree/
https://github.com/adnanaziz/epicode/blob/master/java/src/main/java/com/epi/BinaryTreeLock.java