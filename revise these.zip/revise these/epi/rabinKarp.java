https://www.youtube.com/watch?v=H4VrKHVG5qI
https://www.youtube.com/watch?v=d3TZpfnpJZ0
https://github.com/adnanaziz/epicode/blob/master/java/src/main/java/com/epi/RabinKarp.java