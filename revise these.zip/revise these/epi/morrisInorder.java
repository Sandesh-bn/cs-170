https://www.youtube.com/watch?v=wGXB9OWhPTg
http://www.geeksforgeeks.org/inorder-tree-traversal-without-recursion-and-without-stack/
https://github.com/adnanaziz/epicode/blob/master/java/src/main/java/com/epi/InorderTraversalWithParent.java