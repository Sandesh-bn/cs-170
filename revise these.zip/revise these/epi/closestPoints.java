Let P be a set of n points in the plane. Each point has integer
coordinates. Design an efficient algorithm for computing a line that contains the maximum
number of points in P.